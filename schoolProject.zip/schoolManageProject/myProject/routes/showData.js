var express = require('express');
var router = express.Router();
const verifyjwt = require('../util/verifyJwtToken');
const connection = require('../util/connection');

/* GET home page. */
router.get('/showData', function(req, res, next) {
  const email = req.body.email;
  const pass = req.body.pass;
  
  console.log(email,pass);
    try {
        verifyjwt.verifyJwtAuth(req.cookies.jwtToken.code).then((result) => {
          if (result === 'Verified Successfully') {
            console.log(result)
            connection.query((`select * from studentdata where email = '${email}'`), (error, result, fields) => {
              if (result[0].password === pass && result[0].email === email) {//counter condition needs to add
                console.log(result);
                console.log('login successful');
                connection.query(`select * from studentdata where email = '${email}'`, (error, result) => {
                  if (error) {
                    console.log('Unable to find results!');
                  }
                  res.render('studentData', {result})
                })
              } else {
                res.send('check username / password!')
                console.log(error);
              }
            })
          }
        })
    } catch (e) {
    console.log(e);
    }
});

module.exports = router;
