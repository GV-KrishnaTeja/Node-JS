var express = require('express');
const connection = require('../util/connection');
const jwt = require('jsonwebtoken')
var router = express.Router();

/* GET home page. */
router.post('/checkValidate', function (req, res, next) {
  const email = req.body.email;
  const pass = req.body.pass;
  console.log(email,pass);
  const secret = 'QWER@#$^'
  //res.redirect('/showData');
  connection.query((`select * from studentdata where email = '${email}'`), (error, result, fields) => {
    if (result[0].password === pass && result[0].email === email) {//counter condition needs to add
      console.log(result);
      console.log('login successful');
      jwt.sign({ user: 'IoneTech' }, secret, function (err, token) { // step -1 creating a token
        if (err) {
          console.log(err);
          res.status(500).send(err);
          return;
        } else {
          console.log('Inside');
          tokenGen = token;
          console.log(token);
          const tokenObj = {
            code: token
          }
          res.cookie('jwtToken', tokenObj, { maxAge: 300000 }); // step -2 & 3 , creating a cookie an dloading token in cookie
          res.redirect('/showData');
        }
      })
    } else {
      console.log(error);
      res.send('check username / password!');
    }
  });
})
module.exports = router;


