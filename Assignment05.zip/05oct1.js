//add
var pb = {
    fname : "kitt",
    lname :"gv",
    studies : "BTECH"
}

console.log(pb);


//remove

delete pb.studies
console.log(pb)

//loop 
let z =2
while(z<10){
    console.log(z);
    z++

}



//nested loop

const data = { 
    a: {
      b: [
        10,
        20
      ]
    }
   };
   
  console.log(data);