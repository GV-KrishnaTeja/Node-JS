// for each1

const array1 = ['a', 'b', 'c'];
array1.forEach(element => console.log(element));  

//for each2

const arr = ['doll', 'hippi', 'fish'];
arr.forEach(element => {
    console.log(element);
});


//include


const pets = ['cat', 'dog', 'bat'];
console.log(pets.includes('cat'));

//include2

let arr1 = ['a', 'b', 'c']

console.log(arr1.includes('c', 3))
console.log(arr1.includes('c', 1))

//index of1

	var name1 = [ 'gfg', 'cse', 'geeks', 'portal' ];
	a = name1.indexOf('gfg')
    console.log(a);



//indexof2

var A = [ 1, 2, 3, 4, 5 ];
console.log(a = A.indexOf(2));

//join

const elements = ['current', 'Air', 'earth'];
console.log(elements.join());

//join2

const elements1 = ['kt', 'at', 'sk'];

console.log(elements1.join('-'));