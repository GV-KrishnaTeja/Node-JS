const user = {
    dog: {
        name: "Alex"
    }
    };
    
    console.log(user.cat?.name); 
    console.log(user.dog?.name); 
    
    
