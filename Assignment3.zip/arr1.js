//array .length1

const arr1 = [1,2,3,4,'name',true,null];
console.log(arr1.length);

//array.length2

const arr2 =[1,'qps',44]

console.log(arr2.length);

//array.concat

const array1 = ['a', 'b', 'c'];
const array2 = ['d', 'e', 'f'];
const array3 = array1.concat(array2);

console.log(array3);

//array.concat2

const letters = ['a', 'b', 'c'];
const numbers = [1, 2, 3];

const box = letters.concat(numbers);
console.log(box);