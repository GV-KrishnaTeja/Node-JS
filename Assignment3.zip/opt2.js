let user1 = () =>console.log("xyz");
let user2 = {
dog(){
	console.log("I am xyz");
}
}

user1?.();	 
user2.dog?.(); 
				

