//unshift1

const array1 = [1, 2, 3]
array1.unshift(4, 5);
console.log(array1);


//unshift 2

const cats = ['Bob'];
console.log(cats.unshift()); 


//value1
const array11 = ['a', 'b', 'c','e'];
const iterator = array11.values();
for (const value of iterator) {
  console.log(value);

} 

//vaalue2

const array22 = ['a', 'b',1,2,3,4,5,];
const iterator22 = array22.values();
for (const value of iterator22) {
  console.log(value);

} 